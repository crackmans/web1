package com.kosmo.catpunch.common.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.kosmo.catpunch.controller.CustomAccessDeniedHandler;

import lombok.AllArgsConstructor;

@Configuration
@EnableWebSecurity
@AllArgsConstructor
public class WebSecurityConfig {
	
	private AuthenticationSuccessHandler customSuccessHandler;
	private AuthenticationFailureHandler customFailureHandler;
	/*
	 * //암호화 처리가 진행될 로그인 처리 클래스가 무엇인지 선택 CatUserService catUserService;
	 * 
	 * @Autowired public WebSecurityConfig(CatUserService catUserService) {
	 * this.catUserService = catUserService; }
	 */
	
	//암호화 종류(SHA-2, PBKDF2, Scrypt, Bcrypt 중 Bcrypt 사용
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	//기존 httpsecurity를 변수로 받는 configure 를 스프링2.7 이상에선 이 메소드 형태로 진행해야 함
	//(websecurityconfigureradpater가 deprecated 되어 사용 자제)
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
		http.formLogin()
			.loginPage("/login")
			.loginProcessingUrl("/login_action")
			.defaultSuccessUrl("/login_success")
			.successHandler(customSuccessHandler)
			.failureHandler(customFailureHandler)
			.and()
			.logout()
			.logoutRequestMatcher(new AntPathRequestMatcher("/user/logout"))
			.logoutSuccessUrl("/")
			.invalidateHttpSession(true);
		
		http.exceptionHandling()
			.accessDeniedHandler(accessDeniedHandler());
		
		http.authorizeRequests()
			.antMatchers("/", "/main", "/signup", "/login", "/findid", "/lostpwd").permitAll()
			.antMatchers("/user/mypage", "/login_action", "/login_success").hasAuthority("USER") 
			.antMatchers("/admin/user", "/admin/deleteuser", "/login_action", "/login_success").hasAuthority("ADMIN")
			.and().csrf().disable();
			return http.build();
			//.anyRequest().permitAll()
			//.antMatchers("/user/changepwd", "/user/changeinfo", "/user/updateuser", "/user/deleteuser", "/user/updatepwd", "/user/updatepwd", "/login_success").hasRole("USER")
	}
	
	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception{
		return authenticationConfiguration.getAuthenticationManager();
	}
	//정적 관련 파일(나중에 생길 js, css, image등)에 대해 언제나 접근가능하도록 설정
	/*
	 * @Bean public WebSecurityCustomizer webSecurityCustomizer() { return (web) ->
	 * web.ignoring().antMatchers(null) }
	 */
	
	private AccessDeniedHandler accessDeniedHandler() {
		CustomAccessDeniedHandler accessDeniedHandler = new CustomAccessDeniedHandler();
		accessDeniedHandler.setErrorPage("/denied");
		return accessDeniedHandler;
		
	}
}
