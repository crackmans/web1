package com.kosmo.catpunch.dto;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class CatUserDto implements UserDetails{	
	private int uId;
	private String userId;
	private String userPassword;
	private String userNames;
	private String userTel;
	private String userEmail;
	private String userZipcode;
	private String userStreetAddr;
	private String userDetailedAddr;
	private String userRole;
	private LocalDateTime userJoindate;
	private int userShow;
	
	@JsonIgnore
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return Collections.singletonList(new SimpleGrantedAuthority(this.userRole));
	}
	
	@Override
	public String getPassword() {
		return this.userPassword;
	}
	
	@Override
	public String getUsername() {		
		return this.userId;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}
}
