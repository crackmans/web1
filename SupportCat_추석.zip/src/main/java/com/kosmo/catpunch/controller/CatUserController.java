package com.kosmo.catpunch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kosmo.catpunch.dto.CatUserDto;
import com.kosmo.catpunch.dto.CatUserSearchDto;
import com.kosmo.catpunch.paging.PagingResponse;
import com.kosmo.catpunch.service.CatUserService;
import com.kosmo.catpunch.service.RegisterMail;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class CatUserController {
	
	private final CatUserService catUserService;	
	private final PasswordEncoder passwordEncoder;
	
	@Autowired
	private final RegisterMail registerMail;
	
	// localhost:8080 만 입력하면 main 페이지로 이동
	@GetMapping
	public String mainPage() {
		return "main";
	}
	
	//메인 페이지
	@GetMapping("/main")
	public String main() {
		return "main";
	}

	//관리자 게시판 유저관리 페이지
	@GetMapping("/admin/user")
	public String adminUser(@ModelAttribute("params")final CatUserSearchDto params, Model model) {
		PagingResponse<CatUserDto> users = catUserService.findAllUser(params);
		model.addAttribute("users", users);
		return "adminuser";
	}
	
    // 회원가입 패이지
    @GetMapping("/signup")
    public String openSignUp() {        
        return "signup";
    }
    
    // 로그인 페이지
    @GetMapping("/login")
    public String openLogIn(@RequestParam(value = "error", required = false) String error, @RequestParam(value="exception", required = false) String exception, Model model) {
    	model.addAttribute("error", error);
    	model.addAttribute("exception", exception);
    	return "login";
    }
    
    @GetMapping("/denied")
    public String accessDenied(@RequestParam(value = "exception", required = false)String exception, Model model) {
    	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    	if(authentication instanceof AnonymousAuthenticationToken) {
    		model.addAttribute("username", "허용되지 않은 사용자");
    		model.addAttribute("exception", exception);
    		return "/denied";
    	} 
    	CatUserDto catUserDto = (CatUserDto)authentication.getPrincipal();
    	model.addAttribute("username", catUserDto.getUserId());
    	model.addAttribute("exception", exception);
    	return "/denied";
    }
    
    
    //아이디 찾기 페이지
    @GetMapping("/findid")
    public String opeanFindId() {
    	return "findid";
    }
    
    //아이디 찾기 페이지
    @GetMapping("/lostpwd")
    public String opeanLostPwd() {
    	return "lostpwd";
    }
    
    //유저 비밀번호 변경 페이지 이동
    @PostMapping("/user/changepwd")
    public String changePwd(Model model, @RequestParam String userId) {
    	CatUserDto catUserDto = catUserService.userInfo(userId);
    	model.addAttribute("changepwd", catUserDto);
    	return "changepwd";
    }
    
    //유저 정보 변경페이지 이동
    @PostMapping("/user/changeinfo")
    public String changeInfo(Model model, @RequestParam String userId) {
    	CatUserDto catUserDto = catUserService.userInfo(userId);
    	model.addAttribute("changeinfo", catUserDto);
    	return "changeinfo";
    }
    
    //유저 정보 수정 처리
    @RequestMapping("/user/updateuser")
    public String updateUser(CatUserDto params, @RequestParam String userId) {
    	String url = userId;
    	catUserService.updateUser(params);
    	return "redirect:/user/mypage?userId=" + url;
    }
    
    //유저 자체 삭제 요청 실행
    @PostMapping("/user/deleteuser")
    public String deleteUser(CatUserDto params, @RequestParam int uId) {
    	catUserService.deleteUser(params);
    	return "main";
    }
    
    //관리자게시판 유저 삭제 실행
    @PostMapping("/admin/deleteuser")
    @ResponseBody
    public String admindeleteUser(CatUserDto params, @RequestParam int uId) {
    	catUserService.deleteUser(params);
    	return "adminuser";
    }
    
    //유저 비밀번호 수정 처리
    @RequestMapping("/user/updatepwd")
    public String updatePwd(CatUserDto params, @RequestParam String userId) {
    	String url = userId;
    	catUserService.updatePwd(params);
    	return "redirect:/user/mypage?userId=" +url;
    }
    
    //마이페이지 이동
    @RequestMapping("/user/mypage")
    public String openMyPage(Model model, @RequestParam String userId) {
    	CatUserDto catUserDto = catUserService.userInfo(userId);
    	model.addAttribute("user", catUserDto);
    	return "mypage";
    }
    
    
	/*
	 * // 로그인 실패시 이동
	 * 
	 * @GetMapping("/login_fail") public String loginFail(Model model) {
	 * model.addAttribute("loginErrorMsg", "아이디 또는 비밀번호를 확인하세요."); return "/login";
	 * }
	 */
    
    // 회원가입 진행
    @PostMapping("/save")
    public String saveUser(final CatUserDto params) {
    	catUserService.saveUser(params);
    	return "redirect:/main";
    }
    
    // 로그인 성공
    @GetMapping("/login_success")
    public String loginSuccess(Model model, Authentication authentication) {
    	CatUserDto catUserDto = (CatUserDto)authentication.getPrincipal();
    	model.addAttribute("info", "아이디 : " + catUserDto.getUserId() + ", 이름 : " + catUserDto.getUserNames() + "님 환영합니다.");
    	return "main";    	
    }
    
    
    //아이디 체크 클래스. ajax를 사용하여 json 형태의 데이터를 가져오기때문에 responsebody 어노테이션 사용이 필수이다.
    @PostMapping("/user/idCheck")
    @ResponseBody
    public int idCheck(CatUserDto params) {
    	int cnt = catUserService.idCheck(params);
    	return cnt;
    }
    
    //비밀번호 체크 클래스. ajax를 사용하여 json 형태의 데이터를 가져오기때문에 responsebody 어노테이션 사용이 필수이다.
    @PostMapping("/user/emailCheck")
    @ResponseBody
    public int emailCheck(CatUserDto params) {
    	int cnt = catUserService.emailCheck(params);
    	return cnt;
    }
    
    @PostMapping("/user/myEmailCheck")
    @ResponseBody
    public String myEmailCheck(CatUserDto params) {
    	String curEmail = catUserService.myEmailCheck(params);
    	System.out.println(curEmail);
    	return curEmail;
    }
    
    //비밀번호 체크 클래스. ajax를 사용하여 json 형태의 데이터를 가져오기때문에 responsebody 어노테이션 사용이 필수이다.
    @GetMapping("/user/pwCheck")
    @ResponseBody
    public Boolean pwCheck(Authentication authentication, String inputPw) {
    	CatUserDto catUserDto = (CatUserDto)authentication.getPrincipal();
    	String extPw = catUserDto.getUserPassword();
    	boolean result = passwordEncoder.matches(inputPw, extPw);
    	return result;
    }
    
    //인증메일 발송클래스
    @PostMapping("/mailConfirm")
    @ResponseBody
    String mailConfirm(@RequestParam("email") String email) throws Exception{
    	String code = registerMail.sendSimpleMessage(email);
    	System.out.println("인증코드 : " + code);
    	return code;
    }
    
  //임시 비밀번호 발송 클래스
    @PostMapping("/mailtemppwd")
    String mailTemppwd(CatUserDto catUserDto) throws Exception{
    	String code = registerMail.sendSimplePassword(catUserDto);
    	System.out.println("인증코드 : " + code);
    	return "main";
    }
    
    //아이디 찾기 클래스. 전화번호와 이메일을 변수로 받아 검색한 후 결과값을 반환한다.
    @PostMapping("/findIdCheck")
    @ResponseBody
    public String findUserId(CatUserDto params) {
    	String findId = catUserService.findUserId(params);
    	System.out.println(findId);
    	return findId;
    }
    

}
