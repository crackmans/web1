package com.kosmo.catpunch.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.kosmo.catpunch.dto.CatUserDto;
import com.kosmo.catpunch.dto.CatUserSearchDto;



@Mapper
public interface CatUserMapper {	
	void saveUser(CatUserDto params);
	
	CatUserDto loginUser(String userId);
	
	int idCheck(CatUserDto params);
	
	int emailCheck(CatUserDto params);
	
	String myEmailCheck(CatUserDto params);
	
	CatUserDto userInfo(String userId);
	
	void updateUser(CatUserDto params);
	
	void updatePwd(CatUserDto params);
	
	String findUserId(CatUserDto params);
	
	List<CatUserDto> findAll(CatUserSearchDto params);
	
	void deleteUser(CatUserDto params);
	
	int count(CatUserSearchDto params);

}
