package com.kosmo.catpunch.service;



import java.util.List;

import javax.transaction.Transactional;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.kosmo.catpunch.dto.CatUserDto;
import com.kosmo.catpunch.dto.CatUserSearchDto;
import com.kosmo.catpunch.mapper.CatUserMapper;
import com.kosmo.catpunch.paging.Pagination;
import com.kosmo.catpunch.paging.PagingResponse;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class CatUserService implements UserDetailsService{
	private final CatUserMapper catUserMapper;	
	private final PasswordEncoder passwordEncoder;
	
	//회원가입 진행
	public void saveUser(final CatUserDto params) {	
		String encodePassword = passwordEncoder.encode(params.getUserPassword());
		params.setUserPassword(encodePassword);
		params.setUserRole("USER");
		catUserMapper.saveUser(params);
	}
	
	public PagingResponse<CatUserDto> findAllUser(final CatUserSearchDto params){
		int count = catUserMapper.count(params);
		Pagination pagination = new Pagination(count, params);
		params.setPagination(pagination);
		List<CatUserDto> list = catUserMapper.findAll(params);
		return new PagingResponse<>(list, pagination);
	}
	
	
	//중복 아이디 체크
	public int idCheck(CatUserDto params) {
		int cnt = catUserMapper.idCheck(params);
		return cnt;
	}
	
	//중복 이메일 체크
	public int emailCheck(CatUserDto params) {
		int cnt = catUserMapper.emailCheck(params);
		return cnt;
	}
	
	//
	public String myEmailCheck(CatUserDto params) {
		String curEmail = catUserMapper.myEmailCheck(params);
		return curEmail;
	}
	
	//아이디 찾기
	public String findUserId(CatUserDto params) {
		String findId = catUserMapper.findUserId(params);
		return findId;
	}
	
	//로그인 유저 마이페이지 정보 반환
	public CatUserDto userInfo(String userId) {		
		return catUserMapper.userInfo(userId);
	}
	
	//유저 정보 수정
	public void updateUser(CatUserDto params) {
		catUserMapper.updateUser(params);
	}
	
	//유저 삭제, 탈퇴
	public void deleteUser(CatUserDto params) {
		catUserMapper.deleteUser(params);
	}
	
	//유저 패스워드 수정
	public void updatePwd(CatUserDto params) {
		String encodePassword = passwordEncoder.encode(params.getUserPassword());
		params.setUserPassword(encodePassword);
		catUserMapper.updatePwd(params);
	}
	
	//유저 로그인
	@Override
	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		CatUserDto catUserDto = catUserMapper.loginUser(userId);
		if(catUserDto == null) {
			throw new UsernameNotFoundException("해당하는 유저를 찾을 수 없습니다.");
		}
		return catUserDto;
	}
	
}
